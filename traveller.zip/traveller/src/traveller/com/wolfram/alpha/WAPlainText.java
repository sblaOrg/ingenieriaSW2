/*
 * Created on Dec 9, 2009
 *
 */
package traveller.com.wolfram.alpha;


public interface WAPlainText {

    String getText();
    
}
