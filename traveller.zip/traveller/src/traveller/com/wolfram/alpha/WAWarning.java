/*
 * Created on Dec 8, 2009
 *
 */
package traveller.com.wolfram.alpha;


public interface WAWarning {

    String getType();
    String getText();
    String[][] getAttributes();
}
