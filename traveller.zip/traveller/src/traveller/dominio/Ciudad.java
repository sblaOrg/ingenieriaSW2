package traveller.dominio;

public enum Ciudad{MADRID, PARIS, BSAS, MIAMI;};

