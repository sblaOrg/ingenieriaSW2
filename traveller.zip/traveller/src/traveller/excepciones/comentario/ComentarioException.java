package traveller.excepciones.comentario;

public class ComentarioException extends Exception{
    ComentarioException(){
    }
}
