package traveller.excepciones.evento;

public class EventoException extends Exception{
    EventoException(){
    }
}
