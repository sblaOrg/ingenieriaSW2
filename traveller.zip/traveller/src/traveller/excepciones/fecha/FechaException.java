package traveller.excepciones.fecha;

public class FechaException extends Exception{
    FechaException(){
    }
}
