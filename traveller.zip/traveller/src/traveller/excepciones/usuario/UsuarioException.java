package traveller.excepciones.usuario;

public class UsuarioException extends Exception{
    UsuarioException(){
    }
}
