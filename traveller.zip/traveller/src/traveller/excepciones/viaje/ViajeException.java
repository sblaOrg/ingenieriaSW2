package traveller.excepciones.viaje;

public class ViajeException extends Exception{
    ViajeException(){
    }
}
